def count_in_list(list: list, elem):
    return list.count(elem)
